#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="${1:-$(pwd)}"

if [[ ! -f "$REPO_DIR/pnpm-workspace.yaml" || ! -d "$REPO_DIR/apps/mobile" || ! -d "$REPO_DIR/apps/api" ]]; then
  echo "Error: $REPO_DIR does not look like the Browser-Proxy repo." >&2
  echo "Run this from the repo root, or pass the repo path as the first argument." >&2
  exit 1
fi

BACKUP_DIR="$REPO_DIR/.stage-8c-backup-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$BACKUP_DIR"

while IFS= read -r -d '' source_file; do
  relative="${source_file#"$SCRIPT_DIR/files/"}"
  target="$REPO_DIR/$relative"
  if [[ -f "$target" ]]; then
    mkdir -p "$BACKUP_DIR/$(dirname "$relative")"
    cp "$target" "$BACKUP_DIR/$relative"
  fi
  mkdir -p "$(dirname "$target")"
  cp "$source_file" "$target"
done < <(find "$SCRIPT_DIR/files" -type f -print0)

echo "Stage 8C files applied successfully."
echo "Backup: $BACKUP_DIR"
echo
echo "Next commands:"
echo "  pnpm install --frozen-lockfile"
echo "  pnpm run mobile:typecheck"
echo "  pnpm run api:typecheck"
echo
echo "Render variable: MONGODB_DB_NAME=BrowserProxy"
