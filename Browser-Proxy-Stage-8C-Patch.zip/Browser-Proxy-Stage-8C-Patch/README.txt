Browser-Proxy Stage 8C Patch

Included:
- Account editing fix (API now accepts generated client's PUT request)
- Strong 10-12 character password generator
- Mongo database BrowserProxy and collection accounts
- Real Kotlin Expo native BrowserProfile module
- Native profile creation/status/reset foundation
- Master roadmap broken into checkable stages

Apply:
1. Extract this ZIP.
2. Put the extracted folder beside or inside your repo.
3. From Termux/Codespaces run:
   bash apply-stage-8c.sh /path/to/Browser-Proxy

Then set on Render:
MONGODB_DB_NAME=BrowserProxy

Important:
Changing database does not move documents from the old test database.
