# Stage 8C - Native Profile Manager and Maintenance Patch

## Included

- Account editing now works with the generated client's `PUT /api/accounts/:id` request.
- Random passwords are 10-12 characters and always contain uppercase, lowercase, number and special characters.
- MongoDB defaults to database `BrowserProxy`.
- The account model explicitly uses the lowercase `accounts` collection.
- The Android Expo module now has a Kotlin implementation.
- Native profiles create the following paths:

```text
files/browser-profiles/<accountId>/
  cookies/
  cache/
  storage/
  downloads/
  permissions.json
  profile.json
```

## Render variables

Keep the Atlas SRV in `MONGODB_URI` and add:

```text
MONGODB_DB_NAME=BrowserProxy
```

The code also defaults to `BrowserProxy`, but the explicit Render variable makes deployment intent visible.

## Important migration note

Changing the database from `test` to `BrowserProxy` does not copy existing documents. Existing test accounts must be recreated or migrated before expecting them in the new database.

## Phone checks

1. Build and install a new preview APK.
2. Edit an account and save it.
3. Create an account and inspect the generated password.
4. Open the browser session diagnostics.
5. Confirm the native module reports Android availability and native profile paths.
6. Reset one account session and confirm the account remains but its session state is cleared.
