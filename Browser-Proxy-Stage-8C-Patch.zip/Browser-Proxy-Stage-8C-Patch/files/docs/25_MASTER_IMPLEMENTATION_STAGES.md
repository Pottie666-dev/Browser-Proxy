# Browser-Proxy Master Implementation Stages

This document is the working checklist from the current codebase to the finished platform.

## Completed foundation

### Phase 1 - Account Vault
- [x] Create, list and delete accounts
- [x] MongoDB-backed storage
- [x] Account images, favorites, tags and search
- [ ] Confirm account editing after Stage 8C maintenance patch

### Phase 2 - Identity Generation
- [x] Device name, fake IP and user-agent generation
- [x] Timezone and locale support
- [x] Identity passed into browser runtime

### Phase 3 - Persistent Identity
- [x] Generate identity once per account
- [x] Persist fingerprint, hardware, canvas, audio, WebGL and screen profile

### Phase 4A - JavaScript Runtime Isolation
- [x] Namespaced localStorage/sessionStorage
- [x] JavaScript-visible cookie sandbox
- [x] WebRTC leak blocking and browser API masking

### Phase 4B - Browser State Persistence
- [x] Browser-state API
- [x] Mongo persistence
- [x] Restore JavaScript cookies, storage and history

### Phase 5 - Browser UX
- [x] Tabs, bookmarks, history and browser tools

### Phase 6 - Device Virtualization
- [x] Deterministic device and fingerprint profile
- [x] Region/timezone-aware browser identity

### Phase 7 - Session Controls
- [x] Runtime clear
- [x] Saved session reset
- [x] Diagnostics counters

### Stage 8A - Native Foundation
- [x] Native isolation abstraction
- [x] Profile-path plan
- [x] Native build scripts and diagnostics

### Stage 8B - Native Module Scaffold
- [x] Local Expo module structure
- [x] Per-account profile path API design
- [x] Browser screen integration points

## Current implementation

### Stage 8C - Native Profile Manager and Maintenance Patch
- [x] Fix account editing API method mismatch
- [x] Generate 10-12 character strong passwords
- [x] Force Mongo database `BrowserProxy`
- [x] Force collection name `accounts`
- [x] Add real Kotlin Expo module
- [x] Create, inspect and reset per-account native profile folders
- [ ] Build preview APK
- [ ] Verify native status reports `available: true`
- [ ] Verify edit and strong-password behavior on phone

## Native browser isolation

### Stage 8D - Native WebView Host
- [ ] Replace the shared React Native WebView host with a Browser-Proxy native view
- [ ] Bind each native view to one account profile ID
- [ ] Expose navigation, loading, URL, title and error events to React Native
- [ ] Support back, forward, reload and stop
- [ ] Preserve the existing browser UI

### Stage 8E - Native Cookie Isolation
- [ ] Separate first-party and third-party cookie handling per account
- [ ] Capture native and HTTP-only cookies
- [ ] Restore cookies before navigation
- [ ] Clear one profile without clearing another
- [ ] Add cookie diagnostics and isolation tests

### Stage 8F - Native Storage and Cache Isolation
- [ ] Isolate WebView cache per account
- [ ] Isolate IndexedDB, WebSQL and service-worker state
- [ ] Route DOM storage to the selected account profile
- [ ] Confirm no storage crosses between two test accounts

### Stage 8G - Downloads and Permissions
- [ ] Route downloads to each account's downloads folder
- [ ] Add download progress and open/share actions
- [ ] Store site permission decisions per account
- [ ] Route camera, microphone, location and file chooser requests
- [ ] Add safe permission prompts and reset controls

### Stage 8H - Native Browser Reliability
- [ ] Crash recovery and profile lock handling
- [ ] Clean shutdown and state flush
- [ ] Low-memory recovery
- [ ] Background/foreground lifecycle handling
- [ ] Automated two-account isolation smoke test

## Network identity

### Stage 9A - Proxy Data Model
- [ ] Add proxy records and encrypted credentials
- [ ] Assign one proxy to one or more accounts
- [ ] Add proxy type, host, port, username, password and region
- [ ] Add proxy health and last-check fields

### Stage 9B - Proxy Engine
- [ ] Route all browser traffic through the selected account proxy
- [ ] Support HTTP, HTTPS and SOCKS5
- [ ] Prevent DNS and WebRTC leaks
- [ ] Add sticky-session support
- [ ] Refuse navigation when required proxy protection fails

### Stage 9C - Proxy Management UI
- [ ] Add, edit, test and remove proxies
- [ ] Assign/unassign proxy from account
- [ ] Display current exit IP and region
- [ ] Add failure and rotation controls

## Verification and hardening

### Stage 10A - Fingerprint Verification Dashboard
- [ ] Show effective user-agent, screen, timezone, locale and hardware profile
- [ ] Show WebGL, canvas, audio, media and permission values
- [ ] Compare expected identity with detected identity
- [ ] Flag contradictions and leaks

### Stage 10B - Isolation Test Suite
- [ ] Two-account cookie test
- [ ] Cache and storage crossover test
- [ ] Proxy/IP leak test
- [ ] Fingerprint stability test
- [ ] Reset-account-only test
- [ ] Reinstall/upgrade persistence test

### Stage 10C - Security Hardening
- [ ] Encrypt sensitive local data
- [ ] Encrypt proxy credentials and account secrets at rest
- [ ] Add app lock and optional biometrics
- [ ] Add API authentication and authorization
- [ ] Add rate limits, audit events and safe logging
- [ ] Remove plaintext passwords from ordinary API responses

## Stable native release

### Stage 11A - Release Candidate
- [ ] Clean build from a fresh checkout
- [ ] API, mobile and native type/build checks
- [ ] Install and upgrade tests on physical Android devices
- [ ] Account CRUD, browser, isolation and proxy smoke tests
- [ ] Backup/export and restore validation

### Stage 11B - v1.0 First Stable Native Browser
- [ ] Signed production APK/AAB
- [ ] Release notes and rollback package
- [ ] Stable database migration process
- [ ] User-facing diagnostics and support bundle
- [ ] Tag `v1.0`

## Post-v1 platform expansion

### Stage 12 - Cloud Browser Proof
- [ ] Start secure Chromium container from phone
- [ ] Stream keyboard, pointer, clipboard, upload and download
- [ ] Persist cloud profile per account

### Stage 13 - Cloud Session Platform
- [ ] Session create/status/pause/resume/delete API
- [ ] Container orchestration and cleanup
- [ ] Signed short-lived stream tokens
- [ ] Reconnect and health checks
- [ ] Per-session proxy/VPN

### Stage 14 - Account Ecosystem
- [ ] Per-account inbox and email workflows
- [ ] File and image vault
- [ ] Autofill and credential vault
- [ ] Import/export account packages
- [ ] Optional automation with Playwright and AI controls

## Working instruction format

The user can instruct work using the stage number, for example:

`Start Stage 8D.`

Each stage should be delivered as a tested patch ZIP or an automatic apply script, plus a short deployment and phone-test checklist.
