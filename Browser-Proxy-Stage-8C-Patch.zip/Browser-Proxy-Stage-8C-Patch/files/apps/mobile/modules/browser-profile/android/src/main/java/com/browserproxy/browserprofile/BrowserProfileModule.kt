package com.browserproxy.browserprofile

import android.content.Context
import expo.modules.kotlin.modules.Module
import expo.modules.kotlin.modules.ModuleDefinition
import java.io.File
import org.json.JSONObject

class BrowserProfileModule : Module() {
  override fun definition() = ModuleDefinition {
    Name("BrowserProfile")

    AsyncFunction("getCapabilities") {
      mapOf(
        "available" to true,
        "platform" to "android",
        "supportsProfileDirs" to true,
        "supportsCookieDirectoryPlanning" to true,
        "supportsCacheDirectoryPlanning" to true,
        "supportsDownloadDirectoryPlanning" to true,
        "supportsNativeProfileManager" to true,
        "supportsNativeCookieIsolation" to false,
        "supportsNativeStorageIsolation" to false
      )
    }

    AsyncFunction("prepareProfile") { accountId: String ->
      val paths = profilePaths(requireContext(), accountId)
      ensureProfile(paths)
      pathMap(paths)
    }

    AsyncFunction("getProfilePaths") { accountId: String ->
      pathMap(profilePaths(requireContext(), accountId))
    }

    AsyncFunction("getProfileStatus") { accountId: String ->
      val paths = profilePaths(requireContext(), accountId)
      mapOf(
        "profileId" to paths.profileId,
        "exists" to paths.root.exists(),
        "rootDir" to paths.root.absolutePath,
        "cookieDirExists" to paths.cookies.exists(),
        "cacheDirExists" to paths.cache.exists(),
        "storageDirExists" to paths.storage.exists(),
        "downloadsDirExists" to paths.downloads.exists(),
        "permissionsFileExists" to paths.permissions.exists(),
        "profileFileExists" to paths.profile.exists()
      )
    }

    AsyncFunction("clearProfile") { accountId: String ->
      val paths = profilePaths(requireContext(), accountId)
      if (paths.root.exists()) paths.root.deleteRecursively()
      ensureProfile(paths)
      pathMap(paths)
    }
  }

  private fun requireContext(): Context =
    appContext.reactContext ?: throw IllegalStateException("React context is unavailable")

  private data class ProfilePaths(
    val profileId: String,
    val root: File,
    val cookies: File,
    val cache: File,
    val storage: File,
    val downloads: File,
    val permissions: File,
    val profile: File
  )

  private fun safeId(accountId: String): String {
    val clean = accountId.ifBlank { "default" }.replace(Regex("[^a-zA-Z0-9_-]"), "_")
    return clean.take(120)
  }

  private fun profilePaths(context: Context, accountId: String): ProfilePaths {
    val profileId = safeId(accountId)
    val root = File(context.filesDir, "browser-profiles/$profileId")
    return ProfilePaths(
      profileId = profileId,
      root = root,
      cookies = File(root, "cookies"),
      cache = File(root, "cache"),
      storage = File(root, "storage"),
      downloads = File(root, "downloads"),
      permissions = File(root, "permissions.json"),
      profile = File(root, "profile.json")
    )
  }

  private fun ensureProfile(paths: ProfilePaths) {
    listOf(paths.root, paths.cookies, paths.cache, paths.storage, paths.downloads).forEach { dir ->
      if (!dir.exists() && !dir.mkdirs()) {
        throw IllegalStateException("Unable to create profile directory: ${dir.absolutePath}")
      }
    }

    if (!paths.permissions.exists()) paths.permissions.writeText("{}")
    paths.profile.writeText(
      JSONObject(
        mapOf(
          "profileId" to paths.profileId,
          "schemaVersion" to 1,
          "updatedAt" to System.currentTimeMillis()
        )
      ).toString(2)
    )
  }

  private fun pathMap(paths: ProfilePaths) = mapOf(
    "profileId" to paths.profileId,
    "rootDir" to paths.root.absolutePath,
    "cookieDir" to paths.cookies.absolutePath,
    "cacheDir" to paths.cache.absolutePath,
    "storageDir" to paths.storage.absolutePath,
    "downloadsDir" to paths.downloads.absolutePath,
    "permissionsFile" to paths.permissions.absolutePath,
    "profileFile" to paths.profile.absolutePath
  )
}
